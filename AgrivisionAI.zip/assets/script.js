
const video = document.getElementById("camera")

if(video){
navigator.mediaDevices.getUserMedia({video:true})
.then(stream=>{
video.srcObject=stream
})
}

function capture(){

const canvas = document.getElementById("canvas")
const context = canvas.getContext("2d")

context.drawImage(video,0,0,300,200)

const diseases=[
"Leaf Spot detected",
"Powdery Mildew detected",
"Rust infection detected"
]

const result=diseases[Math.floor(Math.random()*diseases.length)]

document.getElementById("result").innerText="AI Result: "+result

}
